
import React from 'react';
import { Mail } from 'lucide-react';

const Logo: React.FC = () => (
  <div className="flex items-center select-none">
    <svg 
      width="180" 
      height="48" 
      viewBox="0 0 180 48" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className="h-9 md:h-11 w-auto"
    >
      <defs>
        <linearGradient id="refpay_logo_gradient" x1="0" y1="24" x2="160" y2="24" gradientUnits="userSpaceOnUse">
          <stop stopColor="#f97316" />
          <stop offset="0.7" stopColor="#f97316" />
          <stop offset="1" stopColor="#dc2626" />
        </linearGradient>
      </defs>
      <text 
        x="0" 
        y="36" 
        fill="url(#refpay_logo_gradient)"
        style={{ 
          fontFamily: 'Inter, sans-serif', 
          fontWeight: 900, 
          fontSize: '38px',
          letterSpacing: '-0.05em'
        }}
      >
        RefPay
      </text>
    </svg>
  </div>
);

const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <div className="flex items-center transition-transform duration-300 hover:scale-[1.02] cursor-pointer">
          <Logo />
        </div>
        
        <a 
          href="mailto:refpay.pt@gmail.com"
          className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-orange-500/30 transition-all text-sm font-bold tracking-tight text-slate-200 group"
        >
          <Mail className="w-4 h-4 text-orange-500 group-hover:scale-110 transition-transform" />
          <span>Fala connosco</span>
        </a>
      </div>
    </header>
  );
};

export default Header;
