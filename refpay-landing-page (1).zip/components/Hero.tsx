
import React from 'react';
import { Download, ShieldCheck } from 'lucide-react';

interface HeroProps {
  onGetAppClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onGetAppClick }) => {
  return (
    <section className="relative pt-32 pb-16 px-6 lg:pt-56 lg:pb-32 flex flex-col items-center text-center overflow-hidden min-h-[85vh] justify-center">
      {/* Decorative gradient blur */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] md:w-[600px] h-[300px] md:h-[600px] bg-orange-600/10 blur-[80px] md:blur-[120px] rounded-full -z-10" />
      
      <div className="max-w-4xl animate-fade-in">
        <div className="inline-flex items-center gap-2 py-1.5 px-4 bg-orange-600/10 border border-orange-600/20 text-[#f97316] text-[10px] md:text-xs font-black tracking-widest uppercase rounded-full mb-8 backdrop-blur-sm">
          <ShieldCheck className="w-3.5 h-3.5" />
          PLATAFORMA OFICIAL REFPAY 2025
        </div>
        
        <h1 className="text-4xl sm:text-5xl md:text-8xl font-black tracking-tighter mb-6 md:mb-10 leading-[1] md:leading-[0.85] gradient-orange uppercase italic">
          A Sua Carreira com Nova Dinâmica
        </h1>
        
        <p className="text-lg md:text-2xl text-slate-400 mb-10 md:mb-14 max-w-3xl mx-auto leading-relaxed px-2 font-medium">
          O RefPay simplifica a burocracia desportiva, garantindo acesso facilitado aos seus ganhos e nomeações oficiais. Foque-se no que realmente importa: <span className="text-white font-bold italic">o jogo.</span>
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-8">
          <button 
            onClick={onGetAppClick}
            className="group relative w-full sm:w-auto px-10 md:px-12 py-5 md:py-6 bg-gradient-orange rounded-full md:rounded-[48px] font-black text-base md:text-xl flex items-center justify-center gap-3 transition-all hover:scale-105 active:scale-95 shadow-2xl shadow-orange-600/40"
          >
            <Download className="w-6 h-6 group-hover:animate-bounce" />
            OBTER APLICAÇÃO GRATUITA
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
