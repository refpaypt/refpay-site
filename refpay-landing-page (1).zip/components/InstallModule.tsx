
import React, { useState, useEffect } from 'react';
import { Monitor, Smartphone, Apple, X, Share, MoreVertical, PlusSquare, ExternalLink, ChevronLeft } from 'lucide-react';

interface InstallModuleProps {
  onClose: () => void;
  deferredPrompt: any;
  setDeferredPrompt: (prompt: any) => void;
}

enum DeviceType {
  SELECTION = 'selection',
  DESKTOP = 'desktop',
  ANDROID = 'android',
  IOS = 'ios'
}

interface StepProps {
  num: number;
  children: React.ReactNode;
  isLast?: boolean;
}

const APP_URL = "https://refpay-829629585560.us-west1.run.app";

const Step: React.FC<StepProps> = ({ num, children, isLast }) => (
  <div className="flex items-start gap-3 relative">
    {!isLast && (
      <div className="absolute left-3.5 top-7 bottom-0 w-px bg-slate-800 ml-[-0.5px]" />
    )}
    <div className="flex-shrink-0 w-7 h-7 rounded-full bg-orange-500/20 text-orange-500 flex items-center justify-center font-black text-xs border border-orange-500/30 z-10">
      {num}
    </div>
    <div className="text-slate-300 text-[13px] md:text-[15px] leading-relaxed pb-5 pr-2">
      {children}
    </div>
  </div>
);

const InstallModule: React.FC<InstallModuleProps> = ({ onClose }) => {
  const [view, setView] = useState<DeviceType>(DeviceType.SELECTION);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, []);

  const openApp = () => {
    window.open(APP_URL, '_blank');
  };

  const renderSelection = () => (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-3 md:gap-6 animate-fade-in pb-4">
      {[
        { type: DeviceType.ANDROID, icon: Smartphone, label: 'Android', sub: 'Google Chrome' },
        { type: DeviceType.IOS, icon: Apple, label: 'iPhone / iOS', sub: 'Safari' },
        { type: DeviceType.DESKTOP, icon: Monitor, label: 'Computador', sub: 'Chrome / Safari Mac' }
      ].map((item) => (
        <button 
          key={item.type}
          onClick={() => setView(item.type)}
          className="group flex items-center p-5 md:p-8 md:flex-col md:justify-center glass rounded-2xl md:rounded-[48px] border border-slate-800 active:scale-[0.98] transition-all duration-200"
        >
          <div className="w-10 h-10 md:w-16 md:h-16 bg-slate-800/50 rounded-xl md:rounded-2xl flex items-center justify-center mr-4 md:mr-0 md:mb-4 group-hover:text-orange-500 transition-colors">
            <item.icon className="w-6 h-6 md:w-8 md:h-8" />
          </div>
          <div className="text-left md:text-center">
            <span className="text-base md:text-xl font-black uppercase italic tracking-tight text-white block">{item.label}</span>
            <p className="text-slate-500 text-[10px] uppercase tracking-widest font-bold">{item.sub}</p>
          </div>
        </button>
      ))}
    </div>
  );

  const renderDetails = () => {
    switch(view) {
      case DeviceType.DESKTOP:
        return (
          <div className="animate-slide-in-right space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-white/5 border border-white/5">
                <h4 className="text-orange-500 font-black uppercase tracking-widest text-[10px] mb-4 flex items-center gap-2">
                  <Monitor className="w-3 h-3" /> Computador (Chrome)
                </h4>
                <Step num={1}>No computador, abra o <span className="text-white font-bold">Chrome</span>.</Step>
                <Step num={2}>Aceda ao Website que pretenda instalar.</Step>
                <Step num={3}>Na parte superior direita, selecione <span className="text-white italic">Mais (⋮)</span> e, em seguida, <span className="text-white">Transmitir, guardar e partilhar</span> e, em seguida, <span className="text-orange-400 font-bold">Instalar página como app…</span></Step>
                <Step num={4}>Em alguns Websites, na barra de endereço, selecione <span className="text-white font-bold">Instalar</span>.</Step>
                <Step num={5} isLast>Para instalar a app Web, siga as instruções no ecrã.</Step>
              </div>
              <div className="p-5 rounded-2xl bg-white/5 border border-white/5">
                <h4 className="text-blue-400 font-black uppercase tracking-widest text-[10px] mb-4 flex items-center gap-2">
                  <Apple className="w-3 h-3" /> MAC (Safari)
                </h4>
                <Step num={1}>No Safari, abra a página web que pretende utilizar como app web.</Step>
                <Step num={2}>Na barra de menus, selecione <span className="text-white font-bold italic">Ficheiro > Adicionar à Dock</span>. Ou clique no <span className="text-white">Botão de partilha</span> na barra de ferramentas.</Step>
                <Step num={3} isLast>Escreva o nome que pretende utilizar e clique em <span className="text-blue-400 font-bold">Adicionar</span>.</Step>
              </div>
            </div>
            <button onClick={openApp} className="w-full py-5 bg-gradient-orange rounded-full font-black text-lg flex items-center justify-center gap-2 shadow-xl hover:brightness-110 transition-all">
              <ExternalLink className="w-5 h-5" /> Abrir App no Computador
            </button>
          </div>
        );
      case DeviceType.ANDROID:
        return (
          <div className="animate-slide-in-right max-w-lg mx-auto">
            <div className="bg-slate-900/40 p-6 rounded-3xl border border-white/5 mb-6">
              <Step num={1}>No seu dispositivo Android, abra o <span className="text-white font-bold">Chrome</span>.</Step>
              <Step num={2}>Aceda ao Website da aplicação.</Step>
              <Step num={3}>À direita da barra de endereço, toque em <span className="text-white italic">Mais (⋮)</span> e, em seguida, <span className="text-orange-500 font-bold">Adicionar ao ecrã principal</span> e, em seguida, <span className="text-white font-bold">Instalar</span>.</Step>
              <Step num={4} isLast>Siga as instruções no ecrã.</Step>
            </div>
            <button onClick={openApp} className="w-full py-5 bg-gradient-orange rounded-full font-black text-lg flex items-center justify-center gap-3 shadow-xl active:scale-95 transition-transform">
              <Smartphone className="w-6 h-6" /> Abrir App Android
            </button>
          </div>
        );
      case DeviceType.IOS:
        return (
          <div className="animate-slide-in-right max-w-lg mx-auto">
            <div className="bg-slate-900/40 p-5 md:p-6 rounded-3xl border border-white/5 mb-6">
              <Step num={1}>Vá à aplicação <span className="text-white font-bold italic">Safari</span> no iPhone.</Step>
              <Step num={2}>Vá para o site da aplicação.</Step>
              <Step num={3}>Toque em botão <span className="text-white">More</span> e, depois, toque em <span className="text-white font-bold">"Share"</span>.</Step>
              <Step num={4}>Toque no botão <span className="text-blue-400 inline-flex items-center gap-1">Partilhar <Share className="w-4 h-4"/></span>.</Step>
              <Step num={5}>Desloque-se para baixo e toque em <span className="text-orange-500 font-bold uppercase tracking-tight">"Adicionar ao ecrã principal"</span>.</Step>
              <Step num={6}>Se não estiver visível, toque em <span className="text-white italic">"Editar ações"</span> e adicione a opção.</Step>
              <Step num={7}>Ative <span className="text-white font-bold">“Abrir como aplicação web”</span>.</Step>
              <Step num={8} isLast>Toque em <span className="text-orange-500 font-bold">“Adicionar”</span>.</Step>
            </div>
            <button onClick={openApp} className="w-full py-5 bg-gradient-orange rounded-full font-black text-lg flex items-center justify-center gap-3 shadow-xl active:scale-95 transition-transform">
              <ExternalLink className="w-6 h-6" /> Abrir App no Safari
            </button>
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-6 overflow-hidden">
      <div className="absolute inset-0 bg-black/90 backdrop-blur-md" onClick={onClose} />
      
      <div className="relative w-full md:max-w-4xl glass rounded-t-[40px] md:rounded-[60px] overflow-hidden shadow-2xl border-t border-white/10 animate-slide-up flex flex-col max-h-[95vh]">
        {/* Handle visual for mobile accessibility */}
        <div className="w-14 h-1.5 bg-slate-800 rounded-full mx-auto mt-5 mb-2 md:hidden" />
        
        <div className="p-6 md:p-14 overflow-y-auto no-scrollbar">
          <div className="flex items-center justify-between mb-8 md:mb-12">
            <div className="flex items-center gap-4">
              {view !== DeviceType.SELECTION && (
                <button onClick={() => setView(DeviceType.SELECTION)} className="p-2.5 bg-slate-800 rounded-xl active:scale-90 transition-transform">
                  <ChevronLeft className="w-6 h-6" />
                </button>
              )}
              <h2 className="text-xl md:text-5xl font-black tracking-tighter text-white uppercase italic leading-none">
                {view === DeviceType.SELECTION ? 'Instalação ' : 'Instalar no '}<span className="text-orange-500">{view === DeviceType.SELECTION ? 'Passo-a-Passo' : view.toUpperCase()}</span>
              </h2>
            </div>
            <button onClick={onClose} className="p-2.5 bg-slate-800 rounded-xl text-slate-400 active:scale-90 transition-transform">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="pb-6">
            {view === DeviceType.SELECTION ? renderSelection() : renderDetails()}
          </div>
          
          {view === DeviceType.SELECTION && (
            <p className="text-center text-slate-500 text-[10px] md:text-sm uppercase tracking-widest font-bold mt-4 opacity-50">
              Siga as instruções oficiais do seu sistema operativo
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default InstallModule;
