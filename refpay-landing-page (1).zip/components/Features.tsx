
import React from 'react';
import { Calendar, Navigation, FileText, Users } from 'lucide-react';

const features = [
  {
    title: 'Gestão de Jogos (Estratégico e Centralizado)',
    description: 'Centralize todas as suas nomeações oficiais num ecossistema inteligente. Acompanhe o seu histórico desportivo em tempo real e mantenha o seu cronograma organizado, desde o momento da escala até ao apito final.',
    icon: Calendar,
    color: 'text-orange-500',
  },
  {
    title: 'Cálculo de Deslocações (Rigor e Precisão)',
    description: 'Elimine erros manuais e discrepâncias de valores. Calcule as suas deslocações com precisão absoluta através do nosso motor de cálculo baseado em matrizes de zonas e quilometragens oficiais de cada associação.',
    icon: Navigation,
    color: 'text-blue-500',
  },
  {
    title: 'Quitações em PDF (Profissionalismo e Rapidez)',
    description: 'Gere declarações de quitação oficiais em segundos. Documentos prontos a enviar, formatados de acordo com as normas fiscais e personalizáveis para cada entidade, garantindo um profissionalismo impecável na sua faturação.',
    icon: FileText,
    color: 'text-emerald-500',
  },
  {
    title: 'Espaço Sócio (Exclusividade e Comunidade)',
    description: 'Aceda a um espaço exclusivo para membros onde o desporto encontra a tecnologia. Desfrute de parcerias estratégicas, seguros desportivos e receba comunicados diretos das marcas que apoiam a arbitragem de elite.',
    icon: Users,
    color: 'text-purple-500',
  },
];

const Features: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      {features.map((feature, idx) => (
        <div 
          key={idx}
          className="group p-8 glass rounded-[48px] border border-slate-800/50 hover:border-orange-500/30 transition-all duration-300 hover:-translate-y-2"
        >
          <div className={`w-14 h-14 rounded-3xl bg-slate-900 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform ${feature.color}`}>
            <feature.icon className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-black tracking-tight mb-4">{feature.title}</h3>
          <p className="text-slate-400 leading-relaxed text-sm">
            {feature.description}
          </p>
        </div>
      ))}
    </div>
  );
};

export default Features;
