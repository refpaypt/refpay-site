
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0b0f1a] py-16 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col items-center gap-6">
          <div className="flex flex-col items-center">
             <span className="text-3xl font-black gradient-orange italic tracking-tighter mb-2">RefPay</span>
             <p className="text-slate-500 text-xs font-medium uppercase tracking-widest text-center">
               Tecnologia ao serviço da arbitragem portuguesa.
             </p>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-white/5 text-center">
          <p className="text-slate-600 text-[10px] uppercase tracking-[0.2em] font-bold">
            © 2026 REFPAY. TODOS OS DIREITOS RESERVADOS.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
